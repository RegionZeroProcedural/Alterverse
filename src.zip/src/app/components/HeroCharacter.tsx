import Image from "next/image"
import Vesper from "../../../public/heroCharacters/Vesper.png";

export default function HeroCharacter() {
    return(
        <>
            <Image src={Vesper} alt='Vesper'/>
        </>
    )
}