import SignUpButton from "./SignUpButton";
import SignInButton from "./SignInButton";

export default function AccountArea() {
    return(
        <>
            <div className="flex flex-row gap-5 pt-4 ml-8">
                <SignInButton />
                <SignUpButton />
            </div>
        </>
    )
}