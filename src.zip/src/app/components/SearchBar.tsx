"use client";

import { useEffect, useRef } from "react";
import { IoSearch } from "react-icons/io5";

type SearchBarProps = {
  width: number;
  height: number;
  expanded: boolean;
  expandSearch: () => void;
  collapseSearch: () => void;
};

export default function SearchBar({
  width,
  height,
  expanded,
  expandSearch,
  collapseSearch,
}: SearchBarProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Calculate animation progress
  const progress = Math.min(
    Math.max((width - 40) / (200 - 40), 0),
    1
  );

  // Fade the input in as the bar expands
  const inputOpacity = Math.min(
    Math.max((progress - 0.25) / 0.75, 0),
    1
  );

  // Close when clicking outside
  useEffect(() => {
    if (!expanded) return;

    const closeOnOutsidePointer = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) {
        collapseSearch();
      }
    };

    document.addEventListener(
      "pointerdown",
      closeOnOutsidePointer
    );

    return () => {
      document.removeEventListener(
        "pointerdown",
        closeOnOutsidePointer
      );
    };
  }, [expanded, collapseSearch]);

  return (
    <div
      ref={rootRef}
      className="
        absolute
        right-0
        top-1/2
        -translate-y-1/2
        overflow-hidden
        rounded-full
        border
        border-white/20
        bg-[#090a13]/90
        shadow-[0_0_18px_#ae5efa33]
        backdrop-blur-md
      "
      style={{
        width: `${width}px`,
        height: `${height}px`,
      }}
      onMouseEnter={() => {
        if (!expanded) expandSearch();
      }}
      onMouseLeave={() => {
        if (document.activeElement !== inputRef.current) {
          collapseSearch();
        }
      }}
      onKeyDown={(event) => {
        if (event.key === "Escape") {
          collapseSearch();
          inputRef.current?.blur();
        }
      }}
    >
      {/* Search input */}
      <input
        ref={inputRef}
        type="search"
        aria-label="Search"
        placeholder="Search..."
        disabled={!expanded}
        className="
          absolute
          inset-y-0
          left-0
          w-[calc(100%-40px)]
          bg-transparent
          pl-4
          text-sm
          text-white
          outline-none
          placeholder:text-gray-400
        "
        style={{
          opacity: inputOpacity,
        }}
      />

      {/* Search icon */}
      <button
        type="button"
        aria-label={expanded ? "Focus search" : "Open search"}
        className="
          absolute
          inset-y-0
          right-0
          flex
          w-[40px]
          items-center
          justify-center
          text-gray-200
          hover:text-white
        "
        onClick={() => {
          if (!expanded) expandSearch();
          inputRef.current?.focus();
        }}
      >
        <IoSearch
          size={24}
          aria-hidden="true"
        />
      </button>
    </div>
  );
}