"use client";

import useEmblaCarousel from "embla-carousel-react";
import Image from "next/image";

interface characterProps {
    name: string
    genre: string
    born: number /* use Date.now */
    icon: string
    id: string
}
export default function CharacterCarousel() {
    const [emblaRef, emblaApi] = useEmblaCarousel({
    axis: "y",
    loop: true,
    align: "start",
    });

    const characters: characterProps[] = [
        {
            id: "0",
            name: "Vesper",
            genre: "Alt Rock / Dark Pop",
            born: 1795308515,
            icon: "/characterIcons/Vesper icon.png"
        },
        {
            id: "1",
            name: "Luna",
            genre: "Etherial / Dark Electronic",
            born: 1795313011,
            icon: "/characterIcons/Luna icon.png"
        },
        {
            id: "2",
            name: "Exios",
            genre: "Industrial / Cyberpunk",
            born: 1795313091,
            icon: "/characterIcons/Exios icon.png"
        },
        {
            id: "3",
            name: "Lavenda",
            genre: "Alternative R&B / Electronic",
            born: 1795313164,
            icon: "/characterIcons/Lavenda icon.png"
        }
    ]

    return (
        <>
            <div className="embla">
            <div className="embla__viewport" ref={emblaRef}>
                <div className="embla__container z-10">
                    {
                        characters.map((character) => (
                            <div className="embla__slide shrink-0" key={character.id}>
                                <CharacterIcon character={character} />
                            </div>
                        ))
                    }
                </div>
            </div>

            <button className="embla__prev">Scroll to prev</button>
            <button className="embla__next">Scroll to next</button>
            </div>
        </>
    )
}


export function CharacterIcon({
    character
}: {
    character: characterProps
}) {
    return (
        <>
            <Image src={character.icon} alt={character.name} width={80} height={80}/>
        </>
    )
}