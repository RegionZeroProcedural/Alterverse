export default function SignUpButton() {
    return (
        <>
        <button className=" 
            w-35
            h-13
            relative
            rounded-xl
            bg-[image:var(--signUpBtnBg)]
            shadow-[0_0_20px_var(--primaryBtnGlow)]
            border-2
            border-[var(--primaryBtnBorder)]
            alterverseFont
            font-medium
            tracking-wider" >Sign Up</button>
        </>
    )
}