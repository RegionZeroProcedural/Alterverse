"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import SearchBar from "./SearchBar";

const COLLAPSED = { width: 40, height: 40 };
const EXPANDED = { width: 200, height: 50 };
const ANIMATION_DURATION = 500;

type Dimensions = {
  width: number;
  height: number;
};

export default function Search() {
  const [dimensions, setDimensions] = useState<Dimensions>(COLLAPSED);
  const [expanded, setExpanded] = useState(false);

  const dimensionsRef = useRef<Dimensions>(COLLAPSED);
  const frameRef = useRef<number | null>(null);

  // Reusable animation controller
  const animateTo = useCallback((target: Dimensions) => {
    // Cancel any running animation
    if (frameRef.current !== null) {
      cancelAnimationFrame(frameRef.current);
    }

    // Capture the current dimensions
    const start = { ...dimensionsRef.current };
    const startTime = performance.now();

    function frame(now: number) {
      const progress = Math.min(
        (now - startTime) / ANIMATION_DURATION,
        1
      );

      // Smooth easing
      const eased = 1 - Math.pow(1 - progress, 3);

      // Interpolate dimensions
      const next = {
        width:
          start.width +
          (target.width - start.width) * eased,

        height:
          start.height +
          (target.height - start.height) * eased,
      };

      // Store current dimensions
      dimensionsRef.current = next;

      // Update visual dimensions
      setDimensions(next);

      if (progress < 1) {
        frameRef.current = requestAnimationFrame(frame);
      } else {
        frameRef.current = null;
      }
    }

    frameRef.current = requestAnimationFrame(frame);
  }, []);

  // Expand
  const expandSearch = useCallback(() => {
    setExpanded(true);
    animateTo(EXPANDED);
  }, [animateTo]);

  // Collapse
  const collapseSearch = useCallback(() => {
    setExpanded(false);
    animateTo(COLLAPSED);
  }, [animateTo]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (frameRef.current !== null) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, []);

  return (
    <div className="relative z-50 ml-120 mt-5 h-[50px] w-[40px] shrink-0">
      <SearchBar
        width={dimensions.width}
        height={dimensions.height}
        expanded={expanded}
        expandSearch={expandSearch}
        collapseSearch={collapseSearch}
      />
    </div>
  );
}