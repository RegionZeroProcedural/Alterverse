import Link from "next/link"

export default function Nav() {
    return (
        <>
        <div className="gap-16 pt-6 flex flex-row">
            <NavElement name = 'Discover' route = '/discover'/>
            <NavElement name = 'Auctions' route = '/auctions'/>
            <NavElement name = 'Exchange' route = '/exchange'/>
            <NavElement name = 'Studio' route = '/studio'/>
            <NavElement name = 'Creators' route = '/creators' />
        </div>
        </>
    )
}

interface NavElementProps {
    name: string,
    route: string
}

function NavElement({ name, route }: NavElementProps) {
    return(
        <>
            <div className="text-[1.4rem] text-gray-100 font-200">
                <Link href={route}>{name}</Link>
            </div>
        </>
    )
}