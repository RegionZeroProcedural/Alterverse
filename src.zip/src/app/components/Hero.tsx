import PrimaryBtn from "./PrimaryBtn";
import SecondaryBtn from "./SecondaryBtn";
import HeroCharacter from "./HeroCharacter";
import HeroActionCard from "./HeroActionCard";
import ThinDivider from "./ThinDivider";
import HeroEyebrow from "./HeroEyebrow";
import CharacterCarousel from "./CharacterCarousel";

export default function Hero() {

    return (
        <>
            <div className="absolute  ml-40 mt-45">
                <div className="absolute scale-200 translate-y-[-20rem] translate-x-[-20rem] inset-0 z-2 bg-[image:var(--heroShadow)] pointer-events-none" />
                <div className="absolute scale-200 translate-y-[-50rem] translate-x-[-50rem] inset-0 z-2 bg-[image:var(--heroShadow)] pointer-events-none" />
                <HeroEyebrow />
                <div className="text-[11rem] z-10 heroTitle relative overflow-visible w-[60dvw]">
                    BECOME<br/>THE LEGEND.
                </div>
                <div className="text-[1.7rem] z-10 relative heroSubtitle pt-6 translate-x-[-3.5rem]">
                    Discover extraordinary identites. Own their future.
                </div>
                <div className="flex flex-row gap-8">
                    <PrimaryBtn />
                    <SecondaryBtn />
                </div>
                <div className='max-w-[70dvw] relative translate-y-[-39.5rem] translate-x-[28.9rem]'>
                    <HeroCharacter />
                </div>
                <div className="absolute z-10 flex flex-row gap-4 translate-y-[-60rem]">
                    <HeroActionCard 
                        icon={1}
                        title='DISCOVER'
                        desc={<>Explore unique<br/>artist identities.</>}
                    />
                    <ThinDivider />
                    <HeroActionCard 
                        icon={2}
                        title='ACQUIRE'
                        desc={<>Bid, license, or<br/>own a character.</>}
                    />
                    <ThinDivider />
                    <HeroActionCard
                        icon={3} 
                        title='EVOLVE'
                        desc={<>Create, release, and<br/>build their legacy</>}
                    />
                </div>
                <div className="absolute self-end">
                    <CharacterCarousel />
                </div>
            </div>
        </>
    )
}