import { HiSquare3Stack3D } from "react-icons/hi2";
import { TbGavel } from "react-icons/tb";
import { BiSignal4 } from "react-icons/bi";
import { ReactNode } from "react";

interface cardProps {
    title: string;
    desc: ReactNode;
    icon: number;
}

export default function HeroActionCard({ title, desc, icon }: cardProps) {
    return(
    <>
        <div className="flex flex-col w-47 h-50 mt-20 gap-3 actionCards">
            {icon === 1
                ? <HiSquare3Stack3D className="z-10 text-[var(--accent)] min-w-12 min-h-12" size={48}/>
                : icon === 2 ? <TbGavel className="z-10 text-[var(--accent)] min-w-12 min-h-12" size={48}/> 
                : <BiSignal4 className="z-10 text-[var(--accent)] min-w-12 min-h-12" size={48}/>
                }
            <div className="text-[1.65rem] tracking-widest z-10 text-gray-300 actionCardText font-bold">
                {title}
            </div>
            <div className="text-[1.25rem] z-10 tracking-wider text-gray-300 font-light actionCardText leading-6.5">
                {desc}
            </div>
        </div>
    </>
    )
}