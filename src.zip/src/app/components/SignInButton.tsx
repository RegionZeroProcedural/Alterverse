export default function SignInButton() {
    return (
        <>
        <button className="
            w-35
            h-13
            relative
            rounded-xl
            text-shadow-[0_0_18px_var(--primaryBtnGlow)]
            shadow-[0_0_20px_var(--primaryBtnGlow)]
            border-2
            border-[var(--primaryBtnBorder)]
            bg-transparent
            text-gray-100
            alterverseFont
            font-medium
            tracking-wider" >Sign In</button>
        </>
    )
}