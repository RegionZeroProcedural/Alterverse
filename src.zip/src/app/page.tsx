import Header from "./components/Header";
import BackgroundImg from "./components/BackgroundImg";
import Hero from "./components/Hero";

export default function Home() {
  return (
    <>

      <Header />
      <BackgroundImg />
      <div className="w-[100dvw] h-[100dvh] absolute overflow-hidden">
        <Hero />
      </div>        
    </>
  );
}
