"use client";

import useEmblaCarousel from "embla-carousel-react";
import Image from "next/image";
import { useState } from "react";

interface characterProps {
    name: string
    genre: string
    born: number /* use Date.now */
    icon: string
    id: string
}
export default function CharacterCarousel() {
    const [emblaRef, emblaApi] = useEmblaCarousel({
    axis: "y",
    loop: true,
    align: "start",
    });

    const [selectedCharacter, setSelectedCharacter] = useState("0");
    

    const characters: characterProps[] = [
        {
            id: "0",
            name: "Vesper",
            genre: "Alt Rock / Dark Pop",
            born: 1795308515,
            icon: "/characterIcons/Vesper icon.png"
        },
        {
            id: "1",
            name: "Luna",
            genre: "Etherial / Dark Electronic",
            born: 1795313011,
            icon: "/characterIcons/Luna icon.png"
        },
        {
            id: "2",
            name: "Exios",
            genre: "Industrial / Cyberpunk",
            born: 1795313091,
            icon: "/characterIcons/Exios icon.png"
        },
        {
            id: "3",
            name: "Lavenda",
            genre: "Alternative R&B / Electronic",
            born: 1795313164,
            icon: "/characterIcons/Lavenda icon.png"
        }
    ]

    return (
        <>
            <div className="embla flex flex-col">
            <button className="cursor-pointer text-purple-300/70 hover:text-purple-300 translate-x-[0.65rem] hover:translate-y-[-0.2rem] transition-all duration-300">▲</button>
            <div className="embla__viewport p-5" ref={emblaRef}>
    <div className="embla__container z-10 pl-5">
        {characters.map((character) => (
                        <div
                            key={character.id}
                            className={`
                                embla__slide
                                shrink-0
                                rounded-xl
                                overflow-hidden
                                border
                                transition-all
                                hover:-translate-x-3
                                duration-300

                                ${
                                    selectedCharacter === character.id
                                        ? `
                                            opacity-100
                                            border-b-[var(--accent)]
                                            border-r-[var(--accent)]
                                            border-l-[var(--primaryBtnHighlight)]
                                            border-t-[var(--primaryBtnHighlight)]
                                            shadow-[0_0_20px_var(--primaryBtnGlow)]
                                        `
                                        : `
                                            opacity-60
                                            border-white/20
                                            hover:opacity-100
                                            hover:border-[var(--accent)]
                                            hover:shadow-[0_0_10px_var(--primaryBtnGlow)]
                                        `
                                }
                            `}
                        >
                            <button
                                type="button"
                                onClick={() => setSelectedCharacter(character.id)}
                                aria-label={`Select ${character.name}`}
                                aria-pressed={selectedCharacter === character.id}
                                className="block h-full w-full cursor-pointer"
                            >
                                <CharacterIcon character={character} />
                            </button>
                        </div>
                    ))}
                </div>
            </div>
            <button className="cursor-pointer text-purple-300/70 hover:text-purple-300 translate-x-[0.65rem] hover:translate-y-[0.2rem] transition-all duration-300">▼</button>
            </div>
        </>
    )
}


export function CharacterIcon({
    character
}: {
    character: characterProps
}) {
    return (
        <>
            <Image src={character.icon} alt={character.name} width={80} height={80}/>
        </>
    )
}