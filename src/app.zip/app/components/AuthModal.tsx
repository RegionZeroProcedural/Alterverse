import { useAnimationController } from "@/lib/animation controller/AnimationController";
import SignInButton from "./SignInButton";
import SignUpButton from "./SignUpButton";
import { Dispatch, SetStateAction } from "react";
import { HiCubeTransparent } from "react-icons/hi";
import { IoMdCloseCircle } from "react-icons/io";

interface authProps {
    authModalActive: boolean
    setAuthModalActive: Dispatch<SetStateAction<boolean>>
}

export default function AuthModal({authModalActive, setAuthModalActive}: authProps) {

    const [animatedOpacity = 0, animatedHeight = 0] = useAnimationController({
        type: "ease",
        duration: 500,
        reverse: !authModalActive,
        endCoords: [
            1,
            -5,
        ],
    });
    
    return(
        <>  
            <div
                style={{
                    opacity: animatedOpacity,
                    pointerEvents: authModalActive ? "auto" : "none",
                    transform: `translateY(${animatedHeight}rem)`,
                }}
                className="fixed inset-0 z-100 grid place-items-center translate-y-[-5rem]"
            >
                <div className="z-110 w-[25px] h-[25px] absolute text-[1.5rem] translate-y-[-14.5rem] translate-x-[7.5rem] cursor-pointer">
                    <IoMdCloseCircle onClick={() => setAuthModalActive(false)} className="w-8 h-8" />
                </div>
                <div className="z-101 flex place-items-center w-80 h-130 bg-[image:var(--primaryBtnBg)] opacity-60 blur-lg rounded-2xl border-10 border-[var(--primaryBtnHighlight)]">
                </div>
                <div className="absolute z-102 w-70 h-100 bg-[#5900ff] opacity-20 blur-3xl rounded-2xl">
                
                </div>
                <div className="absolute z-102 w-60 h-90 bg-[#000000] opacity-40 blur-xl rounded-2xl">
                
                </div>
                <div className="absolute z-102 w-40 h-65 bg-[#000000] opacity-40 blur-lg rounded-2xl">
                
                </div>
                <div className="z-200 gap-10 flex flex-col absolute w-70 h-120">
                    <HiCubeTransparent className="self-center w-40 h-40 mt-7"/>
                    <input className="bg-[#dddddd66] border-2 border-[#e0e0e072] rounded-md h-9" type="text" placeholder="Username/E-mail"/>
                    <input className="bg-[#dddddd66] border-2 border-[#e0e0e072] rounded-md h-9" type="password" placeholder="Password"/>
                    <div className="flex flex-row gap-5">
                        <SignInButton authModalActive = {authModalActive} setAuthModalActive={setAuthModalActive} mode="submit"/>
                        <SignUpButton authModalActive = {authModalActive} setAuthModalActive={setAuthModalActive} mode="submit"/>
                    </div>
                </div>
            </div>
        </>
    )
}